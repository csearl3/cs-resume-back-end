import json
import boto3
import os
from datetime import datetime, timedelta

# Create DynamoDB resource and import table with env variable
dynamodb = boto3.resource('dynamodb')
table_name = os.environ['TABLE_NAME']
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    
    # Define table variables
    ip_address = event['requestContext']['identity']['sourceIp']
    current_date = datetime.now()
    current_date_str = current_date.strftime("%Y-%m-%d %H:%M:%S")
    ip_hash = str(hash(ip_address))
    unique = False

    # Get the IP hash and previous request date from the DynamoDB table
    response = table.get_item(Key={'IP_Hash': ip_hash})
    
    # Determine if IP hash and timeframe between last visit is unique
    # Put the item into DynamoDB table
    if "Item" in response:
        previous_date_str = response['Item']['Request_Date']
        previous_date_obj = datetime.strptime(previous_date_str, "%Y-%m-%d %H:%M:%S")
        if current_date - timedelta(days=1) > previous_date_obj:
            unique = True
            table.put_item(Item={'IP_Hash': ip_hash, 'Request_Date': current_date_str})
        else:
            unique = False   
    else:
        unique = True
        table.put_item(Item={'IP_Hash': ip_hash, 'Request_Date': current_date_str})

    # Format body and return API response in JSON format
    responseBody = json.dumps({"IP_Hash": ip_hash, "Request_Date": current_date_str, "Unique": unique})
    return {
        "isBase64Encoded": False,
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS, POST" 
        },
        "body": responseBody,
        }
