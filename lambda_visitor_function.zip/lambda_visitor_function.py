import json
import boto3
import os

# Create DynamoDB resource and import table with env variable
dynamodb = boto3.resource('dynamodb')
table_name = os.environ['TABLE_NAME']
table = dynamodb.Table(table_name)

def lambda_handler(event, context):

    # Define function to increment and update visit count into DynamoDB table
    def ddb_update():
        initial = table.get_item(Key={'stat': 'page_views'})
        if "Item" not in initial:
            table.put_item(Item={'stat': 'page_views', 'count': 0})
        
        response = table.update_item(
            Key={'stat': 'page_views'},
            UpdateExpression='SET #C = #C + :val',
            ExpressionAttributeNames={"#C": "count"},
            ExpressionAttributeValues={':val': 1},
            ReturnValues='UPDATED_NEW'
        )
        
        # Return API response in JSON format
        responseBody = json.dumps({"Visitor_Count": int(response["Attributes"]["count"])})
        return {
            "isBase64Encoded": False,
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST" 
            },
            "body": responseBody
        }
    
    # Define function to get visit count from DynamoDB table
    def ddb_read():
        initial = table.get_item(Key={'stat': 'page_views'})
        if "Item" not in initial:
            table.put_item(Item={'stat': 'page_views', 'count': 0})
            
        response = table.get_item(Key={'stat': 'page_views'})
        
        # Return API response in JSON format
        responseBody = json.dumps({"Visitor_Count": int(response["Item"]["count"])})
        return {
            "isBase64Encoded": False,
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, OPTIONS, POST" 
            },
            "body": responseBody
        }

    # Convert event body from escaped string to dict and define available operations
    method = event['httpMethod']
    options = {
        'POST': ddb_update,
        'GET': ddb_read
    }

    # Run the operation specified in event object
    if method in options:
        return options[method]()
    else:
        raise ValueError('Unrecognized operation "{}"'.format(method))
